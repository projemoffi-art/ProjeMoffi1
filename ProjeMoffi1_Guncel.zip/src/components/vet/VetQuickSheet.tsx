"use client";

import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
    X, MapPin, Phone, Star, Calendar, 
    Navigation, ChevronRight, Syringe, 
    ShieldCheck, Clock, ArrowRight,
    Stethoscope, Activity
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useVet } from "@/hooks/useVet";
import { useVaccineSchedule } from "@/hooks/useVaccineSchedule";
import { useRouter, usePathname } from "next/navigation";
import { useTheme } from "@/context/ThemeContext";

interface VetQuickSheetProps {
    isOpen: boolean;
    onClose: () => void;
    petId?: string;
}

export function VetQuickSheet({ isOpen, onClose, petId = "pet-1" }: VetQuickSheetProps) {
    const { theme } = useTheme();
    const router = useRouter();
    const pathname = usePathname();

    const handleOpenModal = (modalName: string) => {
        if (pathname === '/vet') {
            window.dispatchEvent(new CustomEvent('openVetModal', { detail: modalName }));
        } else {
            router.push(`/vet?open=${modalName}`);
        }
        onClose();
    };
    const { featuredClinics, isLoading: isVetLoading } = useVet();
    const { schedule, isLoading: isVaccineLoading } = useVaccineSchedule(petId);

    const nearestClinic = featuredClinics[0];
    const nextVaccine = schedule?.find(v => !v.completed) || schedule?.[0];

    return (
        <AnimatePresence>
            {isOpen && (
                <>
                    {/* Backdrop */}
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={onClose}
                        className="fixed inset-0 z-[3000] bg-black/60 backdrop-blur-sm"
                    />

                    {/* Sheet */}
                    <motion.div
                        initial={{ y: "100%" }}
                        animate={{ y: 0 }}
                        exit={{ y: "100%" }}
                        transition={{ type: "spring", damping: 25, stiffness: 200 }}
                        className="fixed bottom-0 inset-x-0 z-[3001] bg-white dark:bg-[#1C1C1E] rounded-t-[3rem] border-t border-zinc-200 dark:border-card-border shadow-[0_-20px_50px_rgba(0,0,0,0.5)] overflow-hidden flex flex-col max-h-[90vh]"
                    >
                        {/* iOS Style Grab Handle */}
                        <div className="absolute top-3 left-1/2 -translate-x-1/2 w-12 h-1.5 bg-black/10 dark:bg-white/10 rounded-full" />

                        <div className="px-4 sm:px-8 pt-8 sm:pt-10 pb-4 sm:pb-6 flex items-center justify-between">
                            <div>
                                <h3 className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-white tracking-tighter uppercase italic leading-none">Veteriner Hizmetleri</h3>
                                <p className="text-[9px] sm:text-[10px] text-[#5B4D9D] font-black uppercase tracking-[0.2em] sm:tracking-[0.3em] mt-1.5 sm:mt-2">Hızlı Erişim Paneli</p>
                            </div>
                            <button 
                                onClick={onClose}
                                className="w-8 h-8 sm:w-10 sm:h-10 bg-zinc-100 dark:bg-white/5 rounded-full flex items-center justify-center border border-zinc-200 dark:border-card-border hover:bg-zinc-200 dark:hover:bg-black/10 dark:bg-white/10 transition-all"
                            >
                                <X className="w-4 h-4 sm:w-5 sm:h-5 text-zinc-400 dark:text-white/50" />
                            </button>
                        </div>

                        <div className="px-4 sm:px-8 pb-8 sm:pb-12 space-y-6 sm:space-y-8 overflow-y-auto no-scrollbar">
                            
                            {/* 1. NEAREST CLINIC HIGHLIGHT */}
                            <section>
                                <div className="flex items-center justify-between mb-3 sm:mb-4 px-1">
                                    <h4 className="text-[9px] sm:text-[10px] font-black text-zinc-400 dark:text-white/20 uppercase tracking-widest flex items-center gap-2">
                                        <MapPin className="w-3 h-3" /> En Yakın Klinik
                                    </h4>
                                    <span className="text-[8px] sm:text-[9px] font-black text-green-400 bg-green-500/10 px-2 py-0.5 rounded-full uppercase tracking-widest animate-pulse">Açık</span>
                                </div>

                                {isVetLoading ? (
                                    <div className="h-32 bg-zinc-100 dark:bg-white/5 animate-pulse rounded-[1.5rem] sm:rounded-[2rem]" />
                                ) : nearestClinic ? (
                                    <div 
                                        onClick={() => { router.push(`/vet?clinicId=${nearestClinic.id}`); onClose(); }}
                                        className="bg-zinc-50 dark:bg-gradient-to-br dark:from-white/[0.05] dark:to-transparent border border-zinc-200 dark:border-card-border rounded-[1.5rem] sm:rounded-[2.2rem] p-4 sm:p-5 relative group overflow-hidden cursor-pointer active:scale-[0.98] hover:bg-zinc-100/50 dark:hover:bg-white/[0.08] transition-all"
                                    >
                                        <div className="flex items-start gap-3 sm:gap-4 relative z-10">
                                            <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-xl sm:rounded-2xl overflow-hidden border border-zinc-200 dark:border-card-border shrink-0">
                                                <img src={nearestClinic.imageUrl} className="w-full h-full object-cover" />
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <h5 className="font-black text-zinc-900 dark:text-white text-base sm:text-lg mb-0.5 sm:mb-1">{nearestClinic.name}</h5>
                                                <div className="flex items-center gap-2 sm:gap-3">
                                                    <div className="flex items-center gap-1 text-[10px] sm:text-xs text-zinc-500 dark:text-white/40 font-bold">
                                                        <Star className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-yellow-500 fill-current" />
                                                        {nearestClinic.rating}
                                                    </div>
                                                    <div className="w-1 h-1 bg-zinc-300 dark:bg-white/20 rounded-full" />
                                                    <div className="text-[9px] sm:text-xs text-[#5B4D9D] font-black uppercase tracking-tighter">
                                                        {nearestClinic.distance} mesafede
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="flex gap-2 mt-4 sm:mt-5">
                                            <button 
                                                onClick={(e) => { e.stopPropagation(); window.location.href = `tel:${nearestClinic.phone || '02161234567'}`; }}
                                                className="flex-1 bg-zinc-900 dark:bg-card text-white dark:text-black h-10 sm:h-12 rounded-lg sm:rounded-xl font-black text-[10px] sm:text-[11px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-zinc-800 dark:hover:bg-white/90 active:scale-95 transition-all"
                                            >
                                                <Phone className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-current" /> Ara
                                            </button>
                                            <button 
                                                onClick={(e) => { e.stopPropagation(); window.open(`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(nearestClinic.name)}`, '_blank'); }}
                                                className="flex-1 bg-zinc-100 dark:bg-white/5 border border-zinc-200 dark:border-card-border text-zinc-700 dark:text-white h-10 sm:h-12 rounded-lg sm:rounded-xl font-black text-[10px] sm:text-[11px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-zinc-200 dark:hover:bg-black/10 dark:bg-white/10 active:scale-95 transition-all"
                                            >
                                                <Navigation className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> Yol Tarifi
                                            </button>
                                        </div>
                                    </div>
                                ) : null}
                            </section>

                            {/* 2. NEXT VACCINE REMINDER */}
                            <section>
                                <h4 className="text-[9px] sm:text-[10px] font-black text-zinc-400 dark:text-white/20 uppercase tracking-widest mb-3 sm:mb-4 px-1 flex items-center gap-2">
                                    <Syringe className="w-3 h-3" /> Sağlık Durumu
                                </h4>
                                
                                {isVaccineLoading ? (
                                    <div className="h-16 sm:h-20 bg-zinc-100 dark:bg-white/5 animate-pulse rounded-xl sm:rounded-2xl" />
                                ) : nextVaccine ? (
                                    <div className="bg-[#5B4D9D]/10 border border-[#5B4D9D]/20 rounded-[1.2rem] sm:rounded-[1.8rem] p-3 sm:p-5 flex items-center justify-between group">
                                        <div className="flex items-center gap-3 sm:gap-4">
                                            <div className="w-10 h-10 sm:w-12 sm:h-12 bg-[#5B4D9D]/20 rounded-xl sm:rounded-2xl flex items-center justify-center border border-[#5B4D9D]/30">
                                                <Clock className="w-5 h-5 sm:w-6 sm:h-6 text-[#5B4D9D]" />
                                            </div>
                                            <div>
                                                <h6 className="text-zinc-900 dark:text-white font-black text-sm sm:text-base italic uppercase">{nextVaccine.name}</h6>
                                                <p className="text-[#5B4D9D] text-[9px] sm:text-[10px] font-black uppercase tracking-widest mt-0.5">{nextVaccine.date}</p>
                                            </div>
                                        </div>
                                        <div className="bg-[#5B4D9D] text-white px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-md sm:rounded-lg text-[8px] sm:text-[9px] font-black uppercase tracking-widest shadow-xl">
                                            Hatırlat
                                        </div>
                                    </div>
                                ) : null}
                            </section>

                            {/* 3. QUICK ACTION GRID */}
                            <section className="grid grid-cols-2 gap-3 sm:gap-4">
                                <button
                                    onClick={() => handleOpenModal('vaccine')}
                                    className="bg-zinc-50 dark:bg-white/5 border border-zinc-200 dark:border-card-border rounded-[1.2rem] sm:rounded-[1.8rem] p-3 sm:p-5 text-left flex flex-col justify-between h-24 sm:h-32 hover:bg-zinc-100 dark:hover:bg-black/10 dark:bg-white/10 transition-all group"
                                >
                                    <div className="w-8 h-8 sm:w-10 sm:h-10 bg-indigo-500/20 text-indigo-400 rounded-lg sm:rounded-xl flex items-center justify-center border border-indigo-500/20 group-hover:scale-110 transition-transform">
                                        <ShieldCheck className="w-4 h-4 sm:w-5 sm:h-5" />
                                    </div>
                                    <span className="text-[11px] sm:text-sm font-black text-zinc-900 dark:text-white uppercase italic leading-none whitespace-normal">Aşı Karnesi</span>
                                </button>
                                <button
                                    onClick={() => handleOpenModal('appointment')}
                                    className="bg-zinc-50 dark:bg-white/5 border border-zinc-200 dark:border-card-border rounded-[1.2rem] sm:rounded-[1.8rem] p-3 sm:p-5 text-left flex flex-col justify-between h-24 sm:h-32 hover:bg-zinc-100 dark:hover:bg-black/10 dark:bg-white/10 transition-all group"
                                >
                                    <div className="w-8 h-8 sm:w-10 sm:h-10 bg-blue-500/20 text-blue-400 rounded-lg sm:rounded-xl flex items-center justify-center border border-blue-500/20 group-hover:scale-110 transition-transform">
                                        <Stethoscope className="w-4 h-4 sm:w-5 sm:h-5" />
                                    </div>
                                    <span className="text-[11px] sm:text-sm font-black text-zinc-900 dark:text-white uppercase italic leading-none whitespace-normal">Klinik Ara</span>
                                </button>
                            </section>

                            {/* 4. FOOTER: VIEW ALL */}
                            <button
                                onClick={() => { router.push('/vet'); onClose(); }}
                                className="w-full bg-zinc-50 dark:bg-white/5 border border-zinc-200 dark:border-card-border py-4 sm:py-5 rounded-[1.5rem] sm:rounded-[2rem] flex items-center justify-center gap-2 sm:gap-3 group hover:bg-zinc-900 dark:hover:bg-card hover:text-white dark:hover:text-black transition-all"
                            >
                                <span className="text-[10px] sm:text-[11px] font-black uppercase tracking-[0.2em] sm:tracking-[0.3em]">Tüm Detayları Gör</span>
                                <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4 group-hover:translate-x-1 transition-transform" />
                            </button>
                        </div>
                    </motion.div>
                </>
            )}
        </AnimatePresence>
    );
}

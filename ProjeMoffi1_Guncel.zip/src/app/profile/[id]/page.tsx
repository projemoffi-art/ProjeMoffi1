"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
    Camera, Edit3, Check, X, Loader2, AlertCircle, ArrowLeft,
    Settings, Sparkles, BadgeCheck, Crown, MapPin, LinkIcon,
    ChevronRight, User, PawPrint, Grid3X3, Image as ImageIcon,
    Heart, MessageCircle, Share2, Copy, ExternalLink
} from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { apiService } from "@/services/apiService";
import { usePet } from "@/context/PetContext";
import { showToast } from "@/lib/utils";
import { ProfileTab } from "@/components/community/ProfileTab";
import { AddPetModal } from "@/components/community/modals/AddPetModal";
import { EditProfileModal } from "@/components/community/modals/EditProfileModal";

// ── Tab Imports ─────────────────────────────────────────────
import { WalletTab } from "@/components/profile/WalletTab";
import { OrdersTab } from "@/components/profile/OrdersTab";
import { AppointmentsTab } from "@/components/profile/AppointmentsTab";
import { RoutesTab } from "@/components/profile/RoutesTab";
import { FamilyTab } from "@/components/profile/FamilyTab";
import { PassportTab } from "@/components/profile/PassportTab";

import { Wallet, Package, Calendar, Map, Users as UsersIcon, Bookmark, FileText, Activity } from "lucide-react";

// ─── Başharf Avatar Yardımcısı ─────────────────────────────
const AVATAR_COLORS = [
    'from-violet-500 to-purple-700',
    'from-blue-500 to-indigo-700',
    'from-emerald-500 to-teal-700',
    'from-orange-500 to-amber-700',
    'from-rose-500 to-pink-700',
    'from-cyan-500 to-sky-700',
    'from-[#527958] to-emerald-700',
];

function seedColor(seed: string): string {
    let h = 0;
    for (let i = 0; i < seed.length; i++) h = seed.charCodeAt(i) + ((h << 5) - h);
    return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length];
}

function getInitials(name?: string, username?: string, email?: string): string {
    const src = name || username || email || '';
    const parts = src.split(/[\s@_.-]+/).filter(Boolean);
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return src.charAt(0).toUpperCase() || 'M';
}

function isPlaceholderUrl(url?: string | null): boolean {
    if (!url) return true;
    return url === "" || url === "placeholder" || url === "null";
}

// ─────────────────────────────────────────────────────────────

export default function ProfilePage() {
    const params = useParams();
    const router = useRouter();
    const searchParams = useSearchParams();
    const id = params.id as string;
    const { user: currentUser, updateProfile } = useAuth();
    const { pets, activePet, switchPet } = usePet();
    const isOwnProfile = !!(currentUser && (id === currentUser.id || id === 'me'));

    // ── State ──────────────────────────────────────────────
    const [loading, setLoading] = useState(true);
    const [profile, setProfile] = useState<any>(null);
    const [isEditing, setIsEditing] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [activeTab, setActiveTab] = useState<string>('posts');
    const [activeSubView, setActiveSubView] = useState<any>('main');

    useEffect(() => {
        const view = searchParams.get('view');
        if (view) {
            setActiveTab(view);
        }
    }, [searchParams]);

    // ── Follow / Unfollow States & Handlers ─────────────────
    const [isFollowing, setIsFollowing] = useState(false);
    const [followCheckLoading, setFollowCheckLoading] = useState(true);
    const [followLoading, setFollowLoading] = useState(false);

    useEffect(() => {
        if (!id || isOwnProfile || !currentUser) {
            setFollowCheckLoading(false);
            return;
        }
        const checkFollowStatus = async () => {
            setFollowCheckLoading(true);
            try {
                const status = await apiService.isFollowing(id);
                setIsFollowing(status);
            } catch (err) {
                console.error("isFollowing check error:", err);
            } finally {
                setFollowCheckLoading(false);
            }
        };
        checkFollowStatus();
    }, [id, isOwnProfile, currentUser]);

    useEffect(() => {
        const handleFollowChange = (e: any) => {
            if (e.detail && e.detail.userId === id) {
                setIsFollowing(e.detail.isFollowing);
                setProfile((prev: any) => {
                    if (!prev) return prev;
                    const followersChange = e.detail.isFollowing ? 1 : -1;
                    const prevFollowers = prev.stats?.followers || prev.stats?.pack || 0;
                    return {
                        ...prev,
                        stats: {
                            ...prev.stats,
                            followers: Math.max(0, prevFollowers + followersChange)
                        }
                    };
                });
            }
        };
        window.addEventListener('moffi-follow-change', handleFollowChange);
        return () => window.removeEventListener('moffi-follow-change', handleFollowChange);
    }, [id]);

    const handleFollowToggle = async () => {
        if (!currentUser) {
            showToast("Giriş Gerekli", "Takip etmek için önce giriş yapmalısınız!", "User");
            window.dispatchEvent(new CustomEvent('open-auth-modal'));
            return;
        }
        setFollowLoading(true);
        try {
            const newState = !isFollowing;
            if (isFollowing) {
                await apiService.unfollowUser(id);
                showToast("Takibi bıraktınız", "Sparkles", "text-black/60 dark:text-white/60");
            } else {
                await apiService.followUser(id);
                showToast("Takip ediliyor ✨", "Sparkles", "text-emerald-400");
            }
            setIsFollowing(newState);
            setProfile((prev: any) => {
                if (!prev) return prev;
                const prevFollowers = prev.stats?.followers || prev.stats?.pack || 0;
                return {
                    ...prev,
                    stats: {
                        ...prev.stats,
                        followers: Math.max(0, prevFollowers + (newState ? 1 : -1))
                    }
                };
            });
            window.dispatchEvent(new CustomEvent('moffi-follow-change', {
                detail: { userId: id, isFollowing: newState }
            }));
        } catch (err: any) {
            console.error("Follow error:", err);
            showToast("İşlem başarısız: " + (err?.message || "Bilinmeyen hata"), "ShieldAlert", "text-red-500");
        } finally {
            setFollowLoading(false);
        }
    };

    // ── Relations Modal (Followers / Following List) ────────
    const [isRelationsModalOpen, setIsRelationsModalOpen] = useState(false);
    const [relationsModalTab, setRelationsModalTab] = useState<'followers' | 'following'>('followers');
    const [relationsList, setRelationsList] = useState<any[]>([]);
    const [relationsLoading, setRelationsLoading] = useState(false);

    const openRelationsModal = async (tab: 'followers' | 'following') => {
        setRelationsModalTab(tab);
        setIsRelationsModalOpen(true);
        setRelationsLoading(true);
        try {
            const list = tab === 'followers'
                ? await apiService.getFollowers(id)
                : await apiService.getFollowing(id);
            setRelationsList(list);
        } catch (err) {
            console.error("Error loading relations list:", err);
            setRelationsList([]);
        } finally {
            setRelationsLoading(false);
        }
    };

    useEffect(() => {
        const view = searchParams.get('view');
        if (view) {
            setActiveSubView(view);
        } else {
            setActiveSubView('main');
        }
    }, [searchParams, router]);

    // Listen to global moffi-navigate events for instant feedback
    useEffect(() => {
        const handleNavigate = (e: any) => {
            if (isOwnProfile && dest) {
                setActiveSubView(dest);
            }
        };
        window.addEventListener('moffi-navigate', handleNavigate);
        return () => window.removeEventListener('moffi-navigate', handleNavigate);
    }, [isOwnProfile, router]);

    // Edit form state
    const [editName, setEditName] = useState('');
    const [editUsername, setEditUsername] = useState('');
    const [editBio, setEditBio] = useState('');
    const [editAvatarFile, setEditAvatarFile] = useState<File | null>(null);
    const [editAvatarPreview, setEditAvatarPreview] = useState<string | null>(null);
    const [editCoverFile, setEditCoverFile] = useState<File | null>(null);
    const [editCoverPreview, setEditCoverPreview] = useState<string | null>(null);
    const [editAllowComments, setEditAllowComments] = useState(true);
    const [editCommentPrivacy, setEditCommentPrivacy] = useState('everyone');
    const [editFilterWords, setEditFilterWords] = useState('');

    const [isAddPetOpen, setIsAddPetOpen] = useState(false);
    const [addPetStep, setAddPetStep] = useState(1);
    const [newPetName, setNewPetName] = useState('');
    const [newPetType, setNewPetType] = useState('🐶');
    const [newPetBreed, setNewPetBreed] = useState('');
    const [newPetAge, setNewPetAge] = useState('');
    const [newPetGender, setNewPetGender] = useState('Erkek');
    const [newPetNeutered, setNewPetNeutered] = useState('Evet');
    const [newPetSize, setNewPetSize] = useState('Orta');
    const [newPetFeatures, setNewPetFeatures] = useState('');
    const [newPetHealth, setNewPetHealth] = useState('');
    const [newPetCharacter, setNewPetCharacter] = useState('');
    const [newPetMicrochip, setNewPetMicrochip] = useState('');
    const [newPetShowPhone, setNewPetShowPhone] = useState(true);
    const [newPetPhotos, setNewPetPhotos] = useState<any[]>([]);
    const [isSavingPet, setIsSavingPet] = useState(false);
    const [newPetWeight, setNewPetWeight] = useState('');
    const [newPetHealthStatus, setNewPetHealthStatus] = useState('İyi');
    const [newPetActivityTarget, setNewPetActivityTarget] = useState('70');
    const [newPetWaterTarget, setNewPetWaterTarget] = useState('1200');
    const [newPetFoodTarget, setNewPetFoodTarget] = useState('1600');

    // ── Data Fetch ─────────────────────────────────────────
    useEffect(() => {
        if (!id || id === 'me') return;
        const fetchProfile = async () => {
            setLoading(true);
            try {
                const data = await apiService.getUserProfile(id);
                setProfile(data);
            } catch {
                setProfile(null);
            } finally {
                setLoading(false);
            }
        };
        fetchProfile();
    }, [id]);

    // Sync edit form from currentUser
    useEffect(() => {
        if (currentUser && isOwnProfile) {
            setEditName(currentUser.name || currentUser.username || '');
            setEditUsername(currentUser.username || '');
            setEditBio(currentUser.bio || '');
            setEditAvatarPreview(isPlaceholderUrl(currentUser.avatar) ? null : (currentUser.avatar || null));
            setEditCoverPreview(isPlaceholderUrl(currentUser.cover_photo) ? null : (currentUser.cover_photo || null));
            setEditAllowComments(currentUser.settings?.default_allow_comments !== false);
            setEditCommentPrivacy(currentUser.settings?.default_comment_privacy || 'everyone');
            setEditFilterWords(currentUser.settings?.comment_filter_words?.join(', ') || '');
        }
    }, [currentUser, isOwnProfile]);
    const handleSave = async () => {
        console.log('--- Profil Kaydetme Başladı ---');
        console.log('editName:', editName);
        console.log('editUsername:', editUsername);
        console.log('editBio:', editBio);
        console.log('editAvatarFile:', editAvatarFile);
        console.log('editCoverFile:', editCoverFile);
        console.log('Mevcut avatar:', currentUser?.avatar);
        console.log('Mevcut cover:', currentUser?.cover_photo);

        setIsSaving(true);
        try {
            let avatarUrl: string | null = isPlaceholderUrl(currentUser?.avatar) ? null : (currentUser?.avatar || null);
            let coverUrl: string | null = isPlaceholderUrl(currentUser?.cover_photo) ? null : (currentUser?.cover_photo || null);

            console.log('Başlangıç avatarUrl:', avatarUrl);
            console.log('Başlangıç coverUrl:', coverUrl);

            // Upload avatar if new file selected
            if (editAvatarFile) {
                console.log('Yeni avatar yükleniyor...');
                avatarUrl = await apiService.uploadMedia(editAvatarFile, 'avatars');
                console.log('Yeni avatar yüklendi. URL:', avatarUrl);
            }

            // Upload cover if new file selected
            if (editCoverFile) {
                console.log('Yeni kapak yükleniyor...');
                coverUrl = await apiService.uploadMedia(editCoverFile, 'avatars');
                console.log('Yeni kapak yüklendi. URL:', coverUrl);
            }

            console.log('updateProfile çağrılıyor. Payload:', {
                name: editName,
                username: editUsername,
                bio: editBio,
                avatar: avatarUrl,
                cover_photo: coverUrl,
                default_allow_comments: editAllowComments,
                default_comment_privacy: editCommentPrivacy,
                comment_filter_words: editFilterWords.split(',').map(w => w.trim()).filter(Boolean),
            });

            await updateProfile({
                name: editName,
                username: editUsername,
                bio: editBio,
                avatar: avatarUrl,
                cover_photo: coverUrl,
                default_allow_comments: editAllowComments,
                default_comment_privacy: editCommentPrivacy,
                comment_filter_words: editFilterWords.split(',').map(w => w.trim()).filter(Boolean),
            } as any);

            console.log('updateProfile başarılı oldu.');

            // Update local profile state
            setProfile((prev: any) => ({
                ...prev,
                full_name: editName,
                username: editUsername,
                bio: editBio,
                avatar: avatarUrl,
                avatar_url: avatarUrl,
                cover_photo: coverUrl,
                cover_url: coverUrl,
                default_allow_comments: editAllowComments,
                default_comment_privacy: editCommentPrivacy,
                comment_filter_words: editFilterWords.split(',').map(w => w.trim()).filter(Boolean),
            }));

            setIsEditing(false);
            setEditAvatarFile(null);
            setEditCoverFile(null);
            showToast('✅ Profil güncellendi!', 'Sparkles', 'text-cyan-400');
        } catch (err: any) {
            console.error('Kaydetme esnasında hata oluştu:', err);
            showToast('❌ Kayıt başarısız: ' + (err?.message || 'Bilinmeyen hata'), 'ShieldAlert', 'text-red-500');
        } finally {
            setIsSaving(false);
            console.log('--- Profil Kaydetme Bitti ---');
        }
    };

    const handleSavePet = async () => {
        setIsSavingPet(true);
        try {
            let imageUrl = '';
            if (newPetPhotos.length > 0) {
                try {
                    imageUrl = await apiService.uploadMedia(newPetPhotos[0].file, 'avatars');
                } catch {
                    imageUrl = '';
                }
            }
            await apiService.addPet({
                name: newPetName, type: newPetType, breed: newPetBreed,
                age: newPetAge, gender: newPetGender,
                is_neutered: newPetNeutered === 'Evet',
                size: newPetSize, health_notes: newPetHealth,
                character: newPetCharacter, microchip_id: newPetMicrochip,
                show_phone: newPetShowPhone, image: imageUrl || '',
                owner_id: currentUser?.id
            } as any);
            setIsAddPetOpen(false);
            setAddPetStep(1); setNewPetName(''); setNewPetPhotos([]);
            showToast(`${newPetName} aileye hoş geldin! 🐾`, 'Sparkles', 'text-orange-400');
        } catch (err) {
            showToast('Pati kaydedilemedi.', 'ShieldAlert', 'text-red-500');
        } finally {
            setIsSavingPet(false);
        }
    };

    // ── Derived values ──────────────────────────────────────
    const displayUser = isOwnProfile ? currentUser : profile;
    const avatarUrl = isEditing ? editAvatarPreview : (isPlaceholderUrl(displayUser?.avatar || displayUser?.avatar_url) ? null : (displayUser?.avatar || displayUser?.avatar_url || null));
    const coverUrl = isEditing ? editCoverPreview : (isPlaceholderUrl(displayUser?.cover_photo || displayUser?.cover_url) ? null : (displayUser?.cover_photo || displayUser?.cover_url || null));
    const avatarSeed = displayUser?.username || displayUser?.name || displayUser?.email || 'moffi';
    const avatarGradient = seedColor(avatarSeed);
    const initials = getInitials(displayUser?.name, displayUser?.username, displayUser?.email);

    // ── Render: Loading ─────────────────────────────────────
    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center gap-4">
                    <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center shadow-2xl shadow-emerald-500/30">
                        <Loader2 className="w-8 h-8 text-white animate-spin" />
                    </div>
                    <p className="text-black/50 dark:text-white/40 text-xs font-black uppercase tracking-widest">Profil Yükleniyor</p>
                </motion.div>
            </div>
        );
    }

    if (!displayUser && !isOwnProfile) {
        return (
            <div className="min-h-screen flex items-center justify-center p-8 text-center">
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                    <div className="w-20 h-20 rounded-[2rem] bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto">
                        <AlertCircle className="w-10 h-10 text-red-400" />
                    </div>
                    <h2 className="text-2xl font-black text-zinc-900 dark:text-white uppercase italic tracking-tighter">Profil Bulunamadı</h2>
                    <button onClick={() => { if (typeof window !== 'undefined' && window.history.length > 2) { router.back(); } else { router.push('/home'); } }} className="px-6 py-3 bg-white text-black rounded-2xl font-black text-xs uppercase tracking-widest">
                        Ana Sayfaya Dön
                    </button>
                </motion.div>
            </div>
        );
    }

    // Remove separate isOwnProfile return block, so we use the unified layout below.


    // ── PREMIUM PROFILE PAGE ────────────────────────────────
    return (
        <main className="min-h-screen pb-32 overflow-x-hidden">
            {/* ══ HERO — Cover + Avatar ══ */}
            <div className="relative w-full h-72 sm:h-80">
                {/* Cover */}
                {coverUrl ? (
                    <img 
                        src={coverUrl} 
                        className="absolute inset-0 w-full h-full object-cover cursor-pointer" 
                        alt="Kapak" 
                        
                    />
                ) : (
                    <div className="absolute inset-0 bg-gradient-to-br from-[#0f2027] via-[#203a43] to-[#2c5364]">
                        <div className="absolute inset-0 opacity-30"
                            style={{ backgroundImage: 'radial-gradient(circle at 20% 50%, #527958 0%, transparent 50%), radial-gradient(circle at 80% 20%, #1a4731 0%, transparent 40%)' }}
                        />
                    </div>
                )}
                {/* Gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0F] via-[#0A0A0F]/20 to-transparent" />

                <motion.button
                    whileTap={{ scale: 0.9 }}
                    onClick={() => { if (typeof window !== 'undefined' && window.history.length > 2) { router.back(); } else { router.push('/home'); } }}
                    className="absolute top-4 left-4 w-10 h-10 bg-white/80 dark:bg-black/40 backdrop-blur-md rounded-2xl flex items-center justify-center text-zinc-900 dark:text-white border border-black/10 dark:border-white/10 z-10"
                >
                    <ArrowLeft className="w-5 h-5" />
                </motion.button>
                {isOwnProfile && (
                    <motion.button
                        whileTap={{ scale: 0.9 }}
                        onClick={() => window.dispatchEvent(new CustomEvent('open-moffi-settings'))}
                        className="absolute top-4 right-4 w-10 h-10 bg-white/80 dark:bg-black/40 backdrop-blur-md rounded-2xl flex items-center justify-center text-zinc-900 dark:text-white border border-black/10 dark:border-white/10 z-10"
                    >
                        <Settings className="w-5 h-5" />
                    </motion.button>
                )}


                {/* Avatar */}
                <div className="absolute -bottom-14 left-5 z-20">
                    <div className="relative">
                        <div 
                            className="w-28 h-28 rounded-[2rem] border-4 border-[#0A0A0F] overflow-hidden shadow-2xl shadow-black/50 bg-[#111] cursor-pointer"
                            
                        >
                            {avatarUrl ? (
                                <img src={avatarUrl} className="w-full h-full object-cover" alt="Avatar" />
                            ) : (
                                <div className={`w-full h-full bg-gradient-to-tr ${avatarGradient} flex items-center justify-center text-white text-4xl font-black select-none`}>
                                    {initials}
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            {/* ══ PROFILE INFO ══ */}
            <div className="px-5 mt-16">
                {/* Name + actions row */}
                <div className="flex items-start justify-between">
                    <div className="flex-1">
                        <>
                            <div className="flex items-center gap-2">
                                <h1 className="text-2xl font-black text-zinc-900 dark:text-white italic tracking-tighter uppercase leading-tight">
                                    {displayUser?.name || displayUser?.display_name || displayUser?.full_name || displayUser?.username || 'Moffi Kullanıcısı'}
                                </h1>
                                {displayUser?.is_prime && <BadgeCheck className="w-5 h-5 text-emerald-400 shrink-0" />}
                                {(displayUser?.subscription_status === 'plus' || displayUser?.subscription_status === 'pro') && (
                                    <div className="px-2 py-0.5 bg-gradient-to-r from-orange-400 to-yellow-500 rounded-md text-[8px] font-black text-black uppercase italic shadow-lg">PRIME</div>
                                )}
                            </div>
                            <p className="text-emerald-400 font-bold text-sm mt-0.5 tracking-wide">
                                @{displayUser?.username || 'moffi_user'}
                            </p>
                        </>
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center gap-2 ml-3 mt-1">
                        {isOwnProfile ? (
                            <>
                                <motion.button
                                    whileTap={{ scale: 0.9 }}
                                    onClick={() => {
                                        setEditName(currentUser?.name || currentUser?.username || '');
                                        setEditUsername(currentUser?.username || '');
                                        setEditBio(currentUser?.bio || '');
                                        setEditAvatarPreview(isPlaceholderUrl(currentUser?.avatar) ? null : (currentUser?.avatar || null));
                                        setEditCoverPreview(isPlaceholderUrl(currentUser?.cover_photo) ? null : (currentUser?.cover_photo || null));
                                        setIsEditing(true);
                                    }}
                                    className="flex items-center gap-1.5 px-4 py-2.5 bg-zinc-100 dark:bg-white/10 border border-black/10 dark:border-white/10 rounded-2xl text-zinc-900 dark:text-white font-black text-[10px] uppercase tracking-widest hover:bg-zinc-200 dark:hover:bg-white/20 transition-colors"
                                >
                                    <Edit3 className="w-3.5 h-3.5" />
                                    Düzenle
                                </motion.button>
                            </>
                        ) : (
                            <motion.button
                                whileTap={{ scale: 0.95 }}
                                onClick={handleFollowToggle}
                                disabled={followCheckLoading || followLoading}
                                className={`px-6 py-2.5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg transition-all duration-300 flex items-center gap-2 ${
                                    followCheckLoading
                                        ? "bg-emerald-500/50 text-black/50 dark:text-white/50 cursor-not-allowed shadow-none"
                                        : isFollowing
                                        ? "bg-zinc-100 dark:bg-white/10 text-zinc-900 dark:text-white border border-black/10 dark:border-white/10 hover:bg-zinc-200 dark:hover:bg-white/20 shadow-none"
                                        : "bg-emerald-500 text-white shadow-emerald-500/30 hover:bg-emerald-600 hover:shadow-emerald-500/40"
                                }`}
                            >
                                {followCheckLoading || followLoading ? (
                                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                ) : isFollowing ? (
                                    "Takiptesin"
                                ) : (
                                    "Takip Et"
                                )}
                            </motion.button>
                        )}
                    </div>
                </div>

                {/* Bio */}
                <div className="mt-4">
                    {displayUser?.bio && (
                        <p className="text-sm font-medium text-black/60 dark:text-white/60 leading-relaxed max-w-sm ml-1">
                            {displayUser.bio}
                        </p>
                    )}
                </div>

                {/* Stats */}
                <div className="flex items-center gap-6 mt-5 pb-5 border-b border-black/5 dark:border-white/5">
                    {[
                        { value: pets.length || 0, label: 'Pati' },
                        { value: displayUser?.stats?.followers || displayUser?.stats?.pack || 0, label: 'Takipçi', type: 'followers' },
                        { value: displayUser?.stats?.following || 0, label: 'Takip', type: 'following' },
                    ].map(s => (
                        s.type ? (
                            <button
                                key={s.label}
                                onClick={() => openRelationsModal(s.type as any)}
                                className="text-center active:scale-95 transition-transform hover:opacity-85 focus:outline-none"
                            >
                                <p className="text-zinc-900 dark:text-white font-black text-xl leading-tight">{s.value}</p>
                                <p className="text-black/50 dark:text-white/40 text-[10px] font-black uppercase tracking-widest mt-0.5">{s.label}</p>
                            </button>
                        ) : (
                            <div key={s.label} className="text-center">
                                <p className="text-zinc-900 dark:text-white font-black text-xl leading-tight">{s.value}</p>
                                <p className="text-black/50 dark:text-white/40 text-[10px] font-black uppercase tracking-widest mt-0.5">{s.label}</p>
                            </div>
                        )
                    ))}
                </div>



                {/* Tab bar */}
                <div className="flex mt-6 border-b border-white/8 overflow-x-auto no-scrollbar">
                    {(() => {
                        const baseTabs = [
                            { id: 'posts', label: 'Gönderiler', icon: <Grid3X3 className="w-4 h-4" /> },
                            { id: 'pets', label: 'Patiler', icon: <PawPrint className="w-4 h-4" /> },
                        ];
                        const ownerTabs = [
                            ...baseTabs,
                            { id: 'tools', label: 'Araçlarım', icon: <Settings className="w-4 h-4" /> }
                        ];
                        const tabsToDisplay = isOwnProfile ? ownerTabs : baseTabs;

                        const isToolsActive = ['tools', 'wallet', 'orders', 'appointments', 'routes', 'family', 'passport', 'bookmarks'].includes(activeTab);

                        return tabsToDisplay.map(tab => (
                            <button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id as any)}
                                className={`flex-none sm:flex-1 px-3 flex flex-col items-center justify-center gap-1.5 py-3 text-[9px] sm:text-[11px] font-black uppercase tracking-widest transition-colors relative ${
                                    (tab.id === 'tools' ? isToolsActive : activeTab === tab.id) ? 'text-zinc-900 dark:text-white' : 'text-zinc-500 dark:text-white/30 hover:text-zinc-700 dark:hover:text-white/60'
                                }`}
                            >
                                {tab.icon}
                                {tab.label}
                                {(tab.id === 'tools' ? isToolsActive : activeTab === tab.id) && (
                                    <motion.div layoutId="tabIndicator" className="absolute bottom-0 left-1/4 right-1/4 h-0.5 bg-emerald-400 rounded-full" />
                                )}
                            </button>
                        ));
                    })()}
                </div>

                {/* Content tabs */}
                <AnimatePresence mode="wait">
                    {activeTab === 'posts' ? (
                        <motion.div key="posts" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-4">
                            <PostsGrid userId={id} />
                        </motion.div>
                    ) : activeTab === 'pets' ? (
                        <motion.div key="pets" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-6">
                            {pets.length === 0 ? (
                                <div className="text-center py-16 space-y-3">
                                    <div className="w-16 h-16 rounded-[1.5rem] bg-black/5 dark:bg-white/5 border border-white/8 flex items-center justify-center mx-auto mb-4">
                                        <PawPrint className="w-8 h-8 text-black/30 dark:text-white/20" />
                                    </div>
                                    <p className="text-black/50 dark:text-white/40 font-black text-sm uppercase italic">Henüz Pati Yok</p>
                                    {isOwnProfile && (
                                        <button onClick={() => setIsAddPetOpen(true)} className="mt-4 px-6 py-2.5 bg-emerald-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-emerald-500/30">
                                            İlk Patimi Ekle
                                        </button>
                                    )}
                                </div>
                            ) : (
                                <div>
                                    {isOwnProfile && (
                                        <div className="flex justify-end mb-4 px-1">
                                            <button onClick={() => setIsAddPetOpen(true)} className="flex items-center gap-1.5 px-4 py-2 bg-emerald-500/10 text-emerald-500 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-emerald-500/20 transition-colors">
                                                <PawPrint className="w-3.5 h-3.5" />
                                                Yeni Ekle
                                            </button>
                                        </div>
                                    )}
                                    <div className="space-y-3">
                                        {pets.map(pet => (
                                            <motion.div key={pet.id} whileTap={{ scale: 0.99 }} onClick={() => switchPet(pet.id)} className={`flex items-center gap-4 p-4 rounded-[1.5rem] transition-colors cursor-pointer ${activePet?.id === pet.id ? 'bg-emerald-500/10 border border-emerald-500/40' : 'bg-black/5 dark:bg-white/5 border border-black/5 dark:border-white/5 hover:bg-black/10 dark:hover:bg-white/10'}`}>
                                                <div className="w-14 h-14 rounded-2xl overflow-hidden shrink-0">
                                                    {pet.image ? (
                                                        <img src={pet.image} className="w-full h-full object-cover" alt={pet.name} />
                                                    ) : (
                                                        <div className={`w-full h-full bg-gradient-to-tr ${seedColor(pet.name)} flex items-center justify-center text-white text-xl font-black`}>
                                                            {pet.name[0]?.toUpperCase()}
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="flex-1">
                                                    <p className="text-zinc-900 dark:text-white font-black uppercase tracking-tight flex items-center gap-2">
                                                        {pet.name}
                                                        {activePet?.id === pet.id && <div className="w-2 h-2 rounded-full bg-emerald-400" />}
                                                    </p>
                                                    <p className="text-black/50 dark:text-white/40 text-xs font-bold mt-0.5">{pet.breed || 'Tür bilgisi yok'} • {pet.gender || ''}</p>
                                                </div>
                                                <ChevronRight className="w-5 h-5 text-black/30 dark:text-white/20" />
                                            </motion.div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </motion.div>
                    ) : activeTab === 'tools' && isOwnProfile ? (
                        <motion.div key="tools" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-6">
                            
                            {/* Sağlık & Bakım Grubu */}
                            <div className="mb-6">
                                <h3 className="text-[10px] font-black text-black/40 dark:text-white/30 uppercase tracking-[0.2em] mb-3 ml-2 flex items-center gap-2">
                                    <Heart className="w-3 h-3 text-rose-400" /> Sağlık & Bakım
                                </h3>
                                <div className="grid grid-cols-2 gap-3">
                                    <motion.button whileTap={{ scale: 0.97 }} onClick={() => setActiveTab('appointments')} className="col-span-2 p-5 rounded-[1.5rem] bg-gradient-to-br from-rose-500/10 to-pink-500/5 border border-rose-500/20 hover:border-rose-500/40 transition-colors flex items-center justify-between">
                                        <div className="flex items-center gap-3">
                                            <div className="w-10 h-10 rounded-xl bg-rose-500/20 flex items-center justify-center text-rose-500">
                                                <Calendar className="w-5 h-5" />
                                            </div>
                                            <div className="text-left">
                                                <p className="text-sm font-black text-zinc-900 dark:text-white uppercase">Randevular</p>
                                                <p className="text-[9px] font-bold text-rose-500/80 uppercase mt-0.5">Veteriner & Aşı Takvimi</p>
                                            </div>
                                        </div>
                                        <ChevronRight className="w-5 h-5 text-rose-400/50" />
                                    </motion.button>
                                    <motion.button whileTap={{ scale: 0.97 }} onClick={() => setActiveTab('passport')} className="p-4 rounded-[1.5rem] bg-gradient-to-br from-sky-500/10 to-blue-500/5 border border-sky-500/20 hover:border-sky-500/40 transition-colors flex flex-col gap-3">
                                        <div className="w-9 h-9 rounded-xl bg-sky-500/20 flex items-center justify-center text-sky-500">
                                            <FileText className="w-4.5 h-4.5" />
                                        </div>
                                        <div className="text-left">
                                            <p className="text-xs font-black text-zinc-900 dark:text-white uppercase">Pasaport</p>
                                            <p className="text-[8px] font-bold text-sky-500/80 uppercase mt-0.5">Kimlik Bilgileri</p>
                                        </div>
                                    </motion.button>
                                    <motion.button whileTap={{ scale: 0.97 }} onClick={() => setActiveTab('family')} className="p-4 rounded-[1.5rem] bg-gradient-to-br from-purple-500/10 to-indigo-500/5 border border-purple-500/20 hover:border-purple-500/40 transition-colors flex flex-col gap-3">
                                        <div className="w-9 h-9 rounded-xl bg-purple-500/20 flex items-center justify-center text-purple-500">
                                            <UsersIcon className="w-4.5 h-4.5" />
                                        </div>
                                        <div className="text-left">
                                            <p className="text-xs font-black text-zinc-900 dark:text-white uppercase">Aile</p>
                                            <p className="text-[8px] font-bold text-purple-500/80 uppercase mt-0.5">Ortak Bakım</p>
                                        </div>
                                    </motion.button>
                                </div>
                            </div>

                            {/* Finans & Alışveriş Grubu */}
                            <div className="mb-6">
                                <h3 className="text-[10px] font-black text-black/40 dark:text-white/30 uppercase tracking-[0.2em] mb-3 ml-2 flex items-center gap-2">
                                    <Wallet className="w-3 h-3 text-emerald-400" /> Finans & Alışveriş
                                </h3>
                                <div className="grid grid-cols-2 gap-3">
                                    <motion.button whileTap={{ scale: 0.97 }} onClick={() => setActiveTab('wallet')} className="col-span-2 p-5 rounded-[1.5rem] bg-gradient-to-br from-emerald-500/10 to-teal-500/5 border border-emerald-500/20 hover:border-emerald-500/40 transition-colors flex items-center justify-between">
                                        <div className="flex items-center gap-3">
                                            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-500">
                                                <Wallet className="w-5 h-5" />
                                            </div>
                                            <div className="text-left">
                                                <p className="text-sm font-black text-zinc-900 dark:text-white uppercase">Moffi Pay</p>
                                                <p className="text-[9px] font-bold text-emerald-500/80 uppercase mt-0.5">Bakiye & Temassız</p>
                                            </div>
                                        </div>
                                        <ChevronRight className="w-5 h-5 text-emerald-400/50" />
                                    </motion.button>
                                    <motion.button whileTap={{ scale: 0.97 }} onClick={() => setActiveTab('orders')} className="col-span-2 p-4 rounded-[1.5rem] bg-gradient-to-br from-amber-500/10 to-orange-500/5 border border-amber-500/20 hover:border-amber-500/40 transition-colors flex items-center justify-between">
                                        <div className="flex items-center gap-3">
                                            <div className="w-9 h-9 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-500">
                                                <Package className="w-4.5 h-4.5" />
                                            </div>
                                            <div className="text-left">
                                                <p className="text-xs font-black text-zinc-900 dark:text-white uppercase">Siparişler</p>
                                                <p className="text-[8px] font-bold text-amber-500/80 uppercase mt-0.5">Kargo Takibi</p>
                                            </div>
                                        </div>
                                        <ChevronRight className="w-4 h-4 text-amber-400/50" />
                                    </motion.button>
                                </div>
                            </div>

                            {/* Sosyal & Aktivite Grubu */}
                            <div className="mb-6">
                                <h3 className="text-[10px] font-black text-black/40 dark:text-white/30 uppercase tracking-[0.2em] mb-3 ml-2 flex items-center gap-2">
                                    <Activity className="w-3 h-3 text-indigo-400" /> Sosyal & Aktivite
                                </h3>
                                <div className="grid grid-cols-2 gap-3">
                                    <motion.button whileTap={{ scale: 0.97 }} onClick={() => setActiveTab('routes')} className="p-4 rounded-[1.5rem] bg-gradient-to-br from-indigo-500/10 to-blue-500/5 border border-indigo-500/20 hover:border-indigo-500/40 transition-colors flex flex-col gap-3">
                                        <div className="w-9 h-9 rounded-xl bg-indigo-500/20 flex items-center justify-center text-indigo-500">
                                            <Map className="w-4.5 h-4.5" />
                                        </div>
                                        <div className="text-left">
                                            <p className="text-xs font-black text-zinc-900 dark:text-white uppercase">Rotalar</p>
                                            <p className="text-[8px] font-bold text-indigo-500/80 uppercase mt-0.5">Yürüyüşler</p>
                                        </div>
                                    </motion.button>
                                    <motion.button whileTap={{ scale: 0.97 }} onClick={() => setActiveTab('bookmarks')} className="p-4 rounded-[1.5rem] bg-gradient-to-br from-zinc-500/10 to-gray-500/5 border border-zinc-500/20 hover:border-zinc-500/40 transition-colors flex flex-col gap-3">
                                        <div className="w-9 h-9 rounded-xl bg-zinc-500/20 flex items-center justify-center text-zinc-500">
                                            <Bookmark className="w-4.5 h-4.5" />
                                        </div>
                                        <div className="text-left">
                                            <p className="text-xs font-black text-zinc-900 dark:text-white uppercase">Kaydedilenler</p>
                                            <p className="text-[8px] font-bold text-zinc-500/80 uppercase mt-0.5">Koleksiyon</p>
                                        </div>
                                    </motion.button>
                                </div>
                            </div>
                        </motion.div>
                    ) : activeTab === 'wallet' && isOwnProfile ? (
                        <motion.div key="wallet" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="mt-4">
                            <button onClick={() => setActiveTab('tools')} className="mb-4 flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-black/50 dark:text-white/50 hover:text-emerald-500 transition-colors">
                                <ArrowLeft className="w-3.5 h-3.5" /> Geri Dön
                            </button>
                            <WalletTab />
                        </motion.div>
                    ) : activeTab === 'orders' && isOwnProfile ? (
                        <motion.div key="orders" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="mt-4">
                            <button onClick={() => setActiveTab('tools')} className="mb-4 flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-black/50 dark:text-white/50 hover:text-emerald-500 transition-colors">
                                <ArrowLeft className="w-3.5 h-3.5" /> Geri Dön
                            </button>
                            <OrdersTab orders={[]} />
                        </motion.div>
                    ) : activeTab === 'appointments' && isOwnProfile ? (
                        <motion.div key="appointments" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="mt-4">
                            <button onClick={() => setActiveTab('tools')} className="mb-4 flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-black/50 dark:text-white/50 hover:text-emerald-500 transition-colors">
                                <ArrowLeft className="w-3.5 h-3.5" /> Geri Dön
                            </button>
                            <AppointmentsTab appointments={[]} />
                        </motion.div>
                    ) : activeTab === 'passport' && isOwnProfile ? (
                        <motion.div key="passport" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="mt-4">
                            <button onClick={() => setActiveTab('tools')} className="mb-4 flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-black/50 dark:text-white/50 hover:text-emerald-500 transition-colors">
                                <ArrowLeft className="w-3.5 h-3.5" /> Geri Dön
                            </button>
                            {activePet ? (
                                <PassportTab pet={activePet} />
                            ) : (
                                <div className="text-center py-20 opacity-40 font-black text-zinc-900 dark:text-white uppercase tracking-[0.2em]">Lütfen bir pati seçin</div>
                            )}
                        </motion.div>
                    ) : activeTab === 'routes' && isOwnProfile ? (
                        <motion.div key="routes" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="mt-4">
                            <button onClick={() => setActiveTab('tools')} className="mb-4 flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-black/50 dark:text-white/50 hover:text-emerald-500 transition-colors">
                                <ArrowLeft className="w-3.5 h-3.5" /> Geri Dön
                            </button>
                            <RoutesTab routes={[]} activePet={activePet} />
                        </motion.div>
                    ) : activeTab === 'family' && isOwnProfile ? (
                        <motion.div key="family" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="mt-4">
                            <button onClick={() => setActiveTab('tools')} className="mb-4 flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-black/50 dark:text-white/50 hover:text-emerald-500 transition-colors">
                                <ArrowLeft className="w-3.5 h-3.5" /> Geri Dön
                            </button>
                            <FamilyTab />
                        </motion.div>
                    ) : activeTab === 'bookmarks' && isOwnProfile ? (
                        <motion.div key="bookmarks" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="mt-4">
                            <button onClick={() => setActiveTab('tools')} className="mb-4 flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-black/50 dark:text-white/50 hover:text-emerald-500 transition-colors">
                                <ArrowLeft className="w-3.5 h-3.5" /> Geri Dön
                            </button>
                            <div className="text-center py-20 opacity-40 font-black text-zinc-900 dark:text-white uppercase italic tracking-[0.5em]">Koleksiyon Boş</div>
                        </motion.div>
                    ) : null}
                </AnimatePresence>
            </div>

            {/* Add Pet Modal */}
            <AddPetModal
                isOpen={isAddPetOpen} onClose={() => setIsAddPetOpen(false)}
                step={addPetStep} setStep={setAddPetStep}
                newPetName={newPetName} setNewPetName={setNewPetName}
                newPetType={newPetType} setNewPetType={setNewPetType}
                newPetBreed={newPetBreed} setNewPetBreed={setNewPetBreed}
                newPetAge={newPetAge} setNewPetAge={setNewPetAge}
                newPetGender={newPetGender} setNewPetGender={setNewPetGender}
                newPetNeutered={newPetNeutered} setNewPetNeutered={setNewPetNeutered}
                newPetSize={newPetSize} setNewPetSize={setNewPetSize}
                newPetFeatures={newPetFeatures} setNewPetFeatures={setNewPetFeatures}
                newPetHealth={newPetHealth} setNewPetHealth={setNewPetHealth}
                newPetCharacter={newPetCharacter} setNewPetCharacter={setNewPetCharacter}
                newPetMicrochip={newPetMicrochip} setNewPetMicrochip={setNewPetMicrochip}
                newPetShowPhone={newPetShowPhone} setNewPetShowPhone={setNewPetShowPhone}
                newPetPhotos={newPetPhotos} setNewPetPhotos={setNewPetPhotos}
                isSaving={isSavingPet} onSave={handleSavePet}
                newPetWeight={newPetWeight} setNewPetWeight={setNewPetWeight}
                newPetHealthStatus={newPetHealthStatus} setNewPetHealthStatus={setNewPetHealthStatus}
                newPetActivityTarget={newPetActivityTarget} setNewPetActivityTarget={setNewPetActivityTarget}
                newPetWaterTarget={newPetWaterTarget} setNewPetWaterTarget={setNewPetWaterTarget}
                newPetFoodTarget={newPetFoodTarget} setNewPetFoodTarget={setNewPetFoodTarget}
            />

            {/* ══ PREMIUM PROFILE EDIT MODAL ══ */}
            <EditProfileModal
                isOpen={isEditing}
                onClose={() => { setIsEditing(false); setEditAvatarFile(null); setEditCoverFile(null); }}
                user={currentUser}
                editName={editName}
                setEditName={setEditName}
                editUsername={editUsername}
                setEditUsername={setEditUsername}
                editBio={editBio}
                setEditBio={setEditBio}
                editAvatarPreview={editAvatarPreview}
                setEditAvatarPreview={setEditAvatarPreview}
                editCoverPreview={editCoverPreview}
                setEditCoverPreview={setEditCoverPreview}
                editAvatarFile={editAvatarFile}
                setEditAvatarFile={setEditAvatarFile}
                editCoverFile={editCoverFile}
                setEditCoverFile={setEditCoverFile}
                isSavingProfile={isSaving}
                onSave={handleSave}
                editAllowComments={editAllowComments}
                setEditAllowComments={setEditAllowComments}
                editCommentPrivacy={editCommentPrivacy}
                setEditCommentPrivacy={setEditCommentPrivacy}
                editFilterWords={editFilterWords}
                setEditFilterWords={setEditFilterWords}
            />

            {/* ══ RELATIONS MODAL (Followers / Following) ══ */}
            <AnimatePresence>
                {isRelationsModalOpen && (
                    <div className="fixed inset-0 z-[300] flex items-end justify-center">
                        {/* Backdrop */}
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            onClick={() => setIsRelationsModalOpen(false)}
                            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
                        />
                        {/* Drawer */}
                        <motion.div
                            initial={{ y: "100%" }}
                            animate={{ y: 0 }}
                            exit={{ y: "100%" }}
                            transition={{ type: "spring", damping: 25, stiffness: 220 }}
                            className="relative w-full max-w-lg bg-[#0E0E15]/95 backdrop-blur-2xl border-t border-black/10 dark:border-white/10 rounded-t-[3rem] p-6 max-h-[75vh] flex flex-col z-10 overflow-hidden shadow-[0_-15px_40px_rgba(0,0,0,0.6)]"
                        >
                            {/* Drag handle */}
                            <div className="w-12 h-1.5 bg-black/10 dark:bg-white/10 rounded-full mx-auto mb-4 shrink-0" />
                            
                            {/* Header / Tabs */}
                            <div className="flex items-center justify-between border-b border-black/5 dark:border-white/5 pb-4 mb-4 shrink-0">
                                <div className="flex gap-4">
                                    <button
                                        onClick={() => openRelationsModal('followers')}
                                        className={`text-sm font-black uppercase tracking-wider transition-colors ${
                                            relationsModalTab === 'followers' ? 'text-emerald-400' : 'text-black/50 dark:text-white/40'
                                        }`}
                                    >
                                        Takipçiler
                                    </button>
                                    <button
                                        onClick={() => openRelationsModal('following')}
                                        className={`text-sm font-black uppercase tracking-wider transition-colors ${
                                            relationsModalTab === 'following' ? 'text-emerald-400' : 'text-black/50 dark:text-white/40'
                                        }`}
                                    >
                                        Takip Edilenler
                                    </button>
                                </div>
                                <button
                                    onClick={() => setIsRelationsModalOpen(false)}
                                    className="w-7 h-7 bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-full flex items-center justify-center text-black/60 dark:text-white/60 hover:text-white"
                                >
                                    <X className="w-3.5 h-3.5" />
                                </button>
                            </div>

                            {/* List Content */}
                            <div className="flex-1 overflow-y-auto no-scrollbar pb-6">
                                {relationsLoading ? (
                                    <div className="flex flex-col items-center justify-center py-12 gap-3">
                                        <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
                                        <p className="text-black/50 dark:text-white/40 text-[10px] font-black uppercase tracking-widest">Yükleniyor...</p>
                                    </div>
                                ) : relationsList.length === 0 ? (
                                    <div className="flex flex-col items-center justify-center py-12 text-center">
                                        <div className="w-16 h-16 bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl flex items-center justify-center text-black/40 dark:text-white/30 mb-4">
                                            <User className="w-8 h-8" />
                                        </div>
                                        <p className="text-black/60 dark:text-white/60 text-sm font-black uppercase tracking-wider">Henüz Kimse Yok</p>
                                        <p className="text-black/40 dark:text-white/30 text-xs mt-1">Burada listelenecek herhangi bir kullanıcı bulunamadı.</p>
                                    </div>
                                ) : (
                                    <div className="space-y-3">
                                        {relationsList.map((userItem: any) => {
                                            const initials = getInitials(userItem.name, userItem.username);
                                            const gradient = seedColor(userItem.username || userItem.id);
                                            return (
                                                <div
                                                    key={userItem.id}
                                                    onClick={() => {
                                                        setIsRelationsModalOpen(false);
                                                        router.push(`/profile/${userItem.id}`);
                                                    }}
                                                    className="flex items-center justify-between p-3 rounded-2xl bg-black/5 dark:bg-white/5 border border-black/5 dark:border-white/5 hover:bg-black/10 dark:bg-white/10 transition-all cursor-pointer active:scale-[0.98]"
                                                >
                                                    <div className="flex items-center gap-3">
                                                        {/* Avatar */}
                                                        <div className="w-11 h-11 rounded-2xl overflow-hidden border border-black/10 dark:border-white/10 shrink-0 bg-[#222]">
                                                            {userItem.avatar ? (
                                                                <img src={userItem.avatar} className="w-full h-full object-cover" alt="" />
                                                            ) : (
                                                                <div className={`w-full h-full bg-gradient-to-tr ${gradient} flex items-center justify-center text-white text-xs font-black uppercase`}>
                                                                    {initials}
                                                                </div>
                                                            )}
                                                        </div>
                                                        {/* Info */}
                                                        <div>
                                                            <p className="text-zinc-900 dark:text-white font-black text-xs uppercase leading-tight">
                                                                {userItem.name || 'Moffi Kullanıcısı'}
                                                            </p>
                                                            <p className="text-emerald-400 font-bold text-[10px] mt-0.5">
                                                                @{userItem.username || 'moffi_user'}
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <ChevronRight className="w-4 h-4 text-black/40 dark:text-white/30" />
                                                </div>
                                            );
                                        })}
                                    </div>
                                )}
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </main>
    );
}

// ── Posts Grid Bileşeni ──────────────────────────────────────
function PostsGrid({ userId }: { userId: string }) {
    const [posts, setPosts] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [selected, setSelected] = useState<any>(null);

    useEffect(() => {
        if (!userId) { setIsLoading(false); return; }
        const load = async () => {
            setIsLoading(true);
            try {
                const data = await (apiService as any).getUserPosts(userId);
                setPosts(data || []);
            } catch { setPosts([]); }
            finally { setIsLoading(false); }
        };
        load();
    }, [userId]);

    if (isLoading) return (
        <div className="grid grid-cols-3 gap-0.5">
            {Array(9).fill(0).map((_, i) => (
                <div key={i} className="aspect-square bg-white/4 animate-pulse rounded-sm" />
            ))}
        </div>
    );

    if (posts.length === 0) return (
        <div className="flex flex-col items-center py-16 text-center">
            <div className="w-16 h-16 rounded-[1.5rem] bg-black/5 dark:bg-white/5 border border-white/8 flex items-center justify-center mb-4">
                <ImageIcon className="w-8 h-8 text-black/30 dark:text-white/20" />
            </div>
            <p className="text-black/50 dark:text-white/40 font-black text-sm uppercase italic">Henüz Gönderi Yok</p>
        </div>
    );

    return (
        <>
            <div className="grid grid-cols-3 gap-0.5 rounded-2xl overflow-hidden">
                <AnimatePresence>
                    {posts.map((p, i) => (
                        <motion.div
                            key={p.id}
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: i * 0.03 }}
                            className="aspect-square relative overflow-hidden bg-white/4 cursor-pointer group"
                            onClick={() => setSelected(p)}
                        >
                            {p.media_url || p.image ? (
                                <img src={p.media_url || p.image} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt="" />
                            ) : (
                                <div className="w-full h-full bg-gradient-to-br from-emerald-500/10 to-purple-500/10 flex items-center justify-center">
                                    <MessageCircle className="w-6 h-6 text-black/30 dark:text-white/20" />
                                </div>
                            )}
                            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/50 transition-all flex items-center justify-center gap-3 opacity-0 group-hover:opacity-100">
                                <span className="flex items-center gap-1 text-white text-xs font-black"><Heart className="w-4 h-4 fill-white" />{p.likes || 0}</span>
                                <span className="flex items-center gap-1 text-white text-xs font-black"><MessageCircle className="w-4 h-4 fill-white" />{p.comments || 0}</span>
                            </div>
                        </motion.div>
                    ))}
                </AnimatePresence>
            </div>

            {/* Post detail modal */}
            <AnimatePresence>
                {selected && (
                    <>
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                            className="fixed inset-0 z-[500] bg-black/80 backdrop-blur-md" onClick={() => setSelected(null)} />
                        <motion.div initial={{ opacity: 0, scale: 0.9, y: 40 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 40 }}
                            transition={{ type: 'spring', damping: 28, stiffness: 320 }}
                            className="fixed inset-x-4 top-20 bottom-20 z-[510] bg-[#111] rounded-[2.5rem] overflow-hidden flex flex-col border border-white/8 shadow-2xl"
                            onClick={e => e.stopPropagation()}>
                            <div className="relative flex-1 bg-white dark:bg-black">
                                <img src={selected.media_url || selected.image} className="w-full h-full object-contain" alt="" />
                                <button onClick={() => setSelected(null)} className="absolute top-4 right-4 w-9 h-9 bg-black/50 backdrop-blur-md rounded-full flex items-center justify-center text-white border border-black/10 dark:border-white/10">
                                    <X className="w-4 h-4" />
                                </button>
                            </div>
                            {selected.desc && (
                                <div className="p-5 shrink-0">
                                    <p className="text-white text-sm leading-relaxed">{selected.desc}</p>
                                    <div className="flex items-center gap-4 mt-3 text-black/50 dark:text-white/40 text-xs font-bold">
                                        <span className="flex items-center gap-1"><Heart className="w-3.5 h-3.5 text-red-400" />{selected.likes || 0}</span>
                                        <span className="flex items-center gap-1"><MessageCircle className="w-3.5 h-3.5 text-cyan-400" />{selected.comments || 0}</span>
                                        <span className="ml-auto">{selected.time}</span>
                                    </div>
                                </div>
                            )}
                        </motion.div>
                    </>
                )}
            </AnimatePresence>


        </>
    );
}
